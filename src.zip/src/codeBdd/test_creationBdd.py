import unittest
import src.codeBdd.interroBdd as i
import src.codeBdd.creationBdd as c





class Test_Interro_et_Creation_BDD(unittest.TestCase):
    def test_type(self):
        M = i.Interro("Clients","Clients")
        M.creation()

        list_colonne = ['Nom', 'Prenom', 'Path', 'Dette', 'tauxAlcool']  # liste de toutes les colonnes dans la bdd
        M.ajoutColonne(list_colonne[0], 'TEXT', 'nomClient')
        M.ajoutColonne(list_colonne[1], 'TEXT', 'prenomClient')
        M.ajoutColonne(list_colonne[2], 'TEXT', 'Oui')
        M.ajoutColonne(list_colonne[3], 'INTEGER', 0.0)
        M.ajoutColonne(list_colonne[4], 'INTEGER', 0.0)

        list_id = [1, 2]  # liste des id

        # on remplit la première ligne
        M.insertion(list_id[0], 'Nom', 0.0)
        M.update(list_id[0], 'Nom', 'toto')
        M.update(list_id[0], 'Prenom', 'titi')
        M.update(list_id[0], 'Path', 'path_toto_titi')
        M.update(list_id[0], 'Dette', 42)
        M.update(list_id[0], 'tauxAlcool', 54)

        # on remplit la deuxième ligne
        M.insertion(list_id[1], 'Nom', 0.0)
        M.update(list_id[1], 'Nom', 'coco')
        M.update(list_id[1], 'Prenom', 'cici')
        M.update(list_id[1], 'Path', 'path_coco_cici')
        M.update(list_id[1], 'Dette', 420)
        M.update(list_id[1], 'tauxAlcool', 540)

        self.assertIsInstance(M,i.Interro)
        self.assertNotIsInstance(c.modifBDD,c.Bdd)

if __name__ == '__main__':
    unittest.main()