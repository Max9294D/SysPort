from unittest import TestCase
import unittest
from src.codeBdd.interroBdd import *


class TestInterro(TestCase):
    def test_gation_ID(self):

        # on crée une bdd
        bdd = Interro('testGationID', 'testGationID')
        bdd.creation()

        list_colonne = ['Nom','Prenom','Path','Dette','tauxAlcool'] # liste de toutes les colonnes dans la bdd
        bdd.ajoutColonne(list_colonne[0], 'TEXT', 'nomClient')
        bdd.ajoutColonne(list_colonne[1], 'TEXT', 'prenomClient')
        bdd.ajoutColonne(list_colonne[2], 'TEXT', 'Oui')
        bdd.ajoutColonne(list_colonne[3], 'INTEGER', 0.0)
        bdd.ajoutColonne(list_colonne[4], 'INTEGER', 0.0)

        list_id = [1,2]  # liste des id

        # on remplit la première ligne
        bdd.insertion(list_id[0],'Nom',0.0)
        bdd.update(list_id[0],'Nom','toto')
        bdd.update(list_id[0],'Prenom','titi')
        bdd.update(list_id[0],'Path','path_toto_titi')
        bdd.update(list_id[0],'Dette',42)
        bdd.update(list_id[0],'tauxAlcool',54)

        #test gation_id
        A = (bdd.gation_ID(1,'Nom') == 'toto')
        B = (bdd.gation_ID(1,'Prenom') == 'titi')
        C = (bdd.gation_ID(1,'Path') == 'path_toto_titi')
        D = (bdd.gation_ID(1,'Dette') == '42')
        E = (bdd.gation_ID(1,'tauxAlcool') == '54')




        self.assertTrue(A == B, " A != B  --> test_gation_ID : False")
        self.assertTrue(B == C, "B != C  --> test_gation_ID : False")
        self.assertTrue(C == D, "C != D  --> test_gation_ID : False")
        self.assertTrue(D == E, "D != E  --> test_gation_ID : False")
        self.assertTrue(E == True, "E != True  --> test_gation_ID : False")


    def test_gation_index(self):
        # on crée une bdd
        bdd2 = Interro('testGationIndex', 'testGationIndex')
        bdd2.creation()

        list_colonne = ['Nom','Prenom','Path','Dette','tauxAlcool'] # liste de toutes les colonnes dans la bdd
        bdd2.ajoutColonne(list_colonne[0], 'TEXT', 'nomClient')
        bdd2.ajoutColonne(list_colonne[1], 'TEXT', 'prenomClient')
        bdd2.ajoutColonne(list_colonne[2], 'TEXT', 'Oui')
        bdd2.ajoutColonne(list_colonne[3], 'INTEGER', 0.0)
        bdd2.ajoutColonne(list_colonne[4], 'INTEGER', 0.0)

        list_id = [1,2]  # liste des id

        # on remplit la première ligne
        bdd2.insertion(list_id[0],'Nom',0.0)
        bdd2.update(list_id[0],'Nom','toto')
        bdd2.update(list_id[0],'Prenom','titi')
        bdd2.update(list_id[0],'Path','path_toto_titi')
        bdd2.update(list_id[0],'Dette',42)
        bdd2.update(list_id[0],'tauxAlcool',54)

        # on remplit la deuxième ligne
        bdd2.insertion(list_id[1],'Nom',0.0)
        bdd2.update(list_id[1],'Nom','coco')
        bdd2.update(list_id[1],'Prenom','cici')
        bdd2.update(list_id[1],'Path','path_coco_cici')
        bdd2.update(list_id[1],'Dette',420)
        bdd2.update(list_id[1],'tauxAlcool',540)

        #test gation_index
        nom1 = 'toto'
        nom2 = 'coco'
        A = (bdd2.gation_index('\"%s\"'%(nom1),'Nom') == '1')
        B = (bdd2.gation_index('\"%s\"'%(nom2),'Nom') == '2')


        self.assertTrue(A == True, "A != True --> test_gation_index : False")
        self.assertTrue(B == True, "B != True --> test_gation_index : False")




if __name__ == "__main__":
    unittest.main()



